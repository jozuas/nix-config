// ==UserScript==
// @name      youtube.com
// @namespace youtube.com
// @include   https://*.youtube.com/*
// @run-at    document-idle
// ==/UserScript==

function removeSidebarAndComments() {
  let toRemove = [];
  
  toRemove.push(document.getElementById("related"));
  toRemove.push(document.getElementById("secondary"));
  toRemove.push(document.getElementById("comments"));  
  toRemove.forEach((el) => { if (el) { el.remove()} });
}

removeSidebarAndComments();

window.onresize = removeSidebarAndComments;