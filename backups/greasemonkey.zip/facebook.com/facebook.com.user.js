// ==UserScript==
// @name      facebook.com
// @namespace facebook.com
// @include   https://www.facebook.com/
// @run-at    document-idle
// ==/UserScript==

function delayed() {
  document.querySelectorAll("div[role='main']")[0].remove()
}


setTimeout(delayed, 1000);