// ==UserScript==
// @name      learn-clojurescript.com
// @namespace learn-clojurescript.com
// @include   https://*.learn-clojurescript.com/*
// ==/UserScript==

let sheet = window.document.styleSheets[0];
let isToggled = true;

function toggleSidebar() {
  console.log("toggling sidebar");
  if (isToggled) {
    sheet.insertRule(".book-menu { display: none; }", sheet.cssRules.length);
  } else {
    sheet.removeRule(sheet.cssRules.length - 1);
  }
  isToggled = !isToggled;
}

let main = document.getElementsByTagName("main")[0];

let btn = document.createElement("button");
btn.name = "Toggle sidebar";
btn.style.backgroundColor = "#017890";
btn.style.border = "0px";
btn.onclick = toggleSidebar;

main.prepend(btn);